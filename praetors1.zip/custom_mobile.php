<?php
$page = 'Home';
$pageDesc = '""';
include 'includes/header1.php';
?>


<!-- Inner banner sec start -->
<section class="inner-banner">
    <img src="images/inner-bg1.png" alt="" class="inner-bg1">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-7 col-md-12">
                <div>
                    <h5>Home > Services > Custom Mobile Application Development</h5>
                    <h1>Custom Mobile App Development Services</h1>
                    <p>
                        With nearly two decades of delivering cutting-edge solutions, The Praetors is the premier
                        partner for enterprises seeking to elevate their mobile presence. Our dedicated team of
                        developers, designers and product strategists have extensive expertise crafting native
                        applications optimized for iOS and Android environments.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-5 col-md-12">
                <div>
                    <img src="images/cust-mob-bn.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Inner banner sec end -->

<!-- partner with sec start -->
<section class="partner-with">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div>
                    <img src="images/cust-mob1.jpg" alt="" class="and1">
                    <h2>
                        Seize New Opportunities - Partner With The Praetors For Intuitive Mobile App Design And
                        Development Services
                    </h2>
                    <p>
                        In today's experience-led business landscape, a compelling mobile presence is crucial for any
                        organization seeking to stay ahead of the curve. As the architects behind countless innovative
                        apps, The Praetors understands how carefully calibrated solutions can deepen user engagement,
                        fuel growth strategies and optimize processes across industries. Our solutions-driven approach
                        in mobile application development leverages deep technological know-how alongside UX design
                        precision to bring ideas to fruition within budget.
                    </p>
                    <p>
                        With proven delivery of projects both large and small, The Praetors is an elite mobile partner
                        empowering disruptive innovation through intuitively crafted interfaces, advanced integrations
                        and rich feature sets tailored to client ambitions.
                    </p>
                    <a href="" class="btn1">
                        Lets Build Your Android App Now
                    </a>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 ps-3">
                <div class="our-serv-headings">
                    <h6>Our Services</h6>
                    <ul>
                        <li class="active">
                            <a href="">
                                <h5>Android App Development</h5>
                                <h5>(2)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>iOS App Development</h5>
                                <h5>(2)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>Digital solutions</h5>
                                <h5>(3)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>strategy & Research</h5>
                                <h5>(4)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>Business Model</h5>
                                <h5>(3)</h5>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="ready-to-help">
                    <img src="images/and2.jpg" alt="" class="and2">
                    <div>
                        <img src="images/logo.png" alt="">
                        <h6>
                            We’re Always ready
                            for help You
                        </h6>
                        <a href="" class="btn1">Need Help <i class="far fa-chevron-double-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- partner with sec end -->

<!-- connect with audience start -->
<section class="con-audience">
    <img src="images/seamless-bg.png" alt="" class="seamless-bg">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="heading">
                    <h2>
                        Level Up Your Mobile Strategy With Our Custom Mobile App Development Services
                    </h2>
                    <p>
                        Does your app portfolio still meet evolving user demands? The Praetors helps visionary brands
                        transform the way they engage audiences through custom mobile solutions. From concept to
                        maintenance, our dedicated teams handle every facet of the development lifecycle, eliminating
                        roadblocks and accelerating ROI.
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-12 col-lg-4 col-md-6 mb-5">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Multi-Platform
                        Accessibility
                    </h4>
                    <p>
                        Our apps are meticulously crafted to function seamlessly across various platforms, ensuring a
                        consistent user experience regardless of the device or operating system used.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Native App Experience
                    </h4>
                    <p>
                        Our apps provide users with a native-like experience, boasting smooth performance and intuitive
                        interfaces akin to traditional native applications.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Technical Maintenance
                        & Support
                    </h4>
                    <p>
                        We offer comprehensive technical maintenance and support services to ensure that your app
                        remains updated, secure, and fully operational, providing peace of mind to both you and your
                        users.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- connect with audience end -->

<!-- seamless mobile exp start-->
<section class="mobile_exp">
    <div class="container">
        <div class="row">
            <div class="col-12 col-xl-10">
                <div class="heading_section aos-init aos-animate" data-aos="fade-right" data-aos-duration="3000">
                    <h5>Explore Our Portfolio</h5>
                    <h2>Seamless Mobile App Experience</h2>
                    <p>Our project portfolio showcases the diverse array of innovative mobile and web apps we've
                        developed for organizations worldwide. Each case study highlights how our end-to-end services
                        and technical expertise bring ambitious ideas to market and deliver tangible business impact
                        through digital solutions tailored to our clients' needs. Peruse the portfolio to see examples
                        of stunning UX design, smooth functionality, and platform-optimized performance across
                        industries. Let the work speak for itself!
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-7 col-md-6">
                <div>
                    <img src="images/custmob1.png" alt="" class="mobile_exp-img1">
                    <img src="images/custmob2.png" alt="" class="mobile_exp-img2">
                </div>
            </div>
            <div class="col-12 col-lg-5 col-md-6">
                <div>
                    <img src="images/custmob3.png" alt="" class="mobile_exp-img3">
                    <img src="images/custmob4.png" alt="" class="mobile_exp-img4">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- seamless mobile exp end-->


<!-- technologies sec start -->
<section class="tech-sec ande-tech-sec">
    <div class="container">
        <div class="text-center mb-5 pb-3">
            <h2>Technologies And Platforms We Use</h2>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="tech-slider pt-5">
                    <div class="tech-slide">
                        <img src="images/tec1.png" alt="" class="tec1">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec2.png" alt="" class="tec2">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec3.png" alt="" class="tec3">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec4.png" alt="" class="tec4">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec5.png" alt="" class="tec5">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec6.png" alt="" class="tec6">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec7.png" alt="" class="tec7">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec17.png" alt="" class="tec17">
                    </div>
                </div>
                <div class="tech-slider1 pt-5">
                    <div class="tech-slide">
                        <img src="images/tec9.png" alt="" class="tec15">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec10.png" alt="" class="tec10">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec11.png" alt="" class="tec11">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec12.png" alt="" class="tec12">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec13.png" alt="" class="tec13">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec14.png" alt="" class="tec14">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec15.png" alt="" class="tec15">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec16.png" alt="" class="tec16">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec17.png" alt="" class="tec17">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- technologies sec end -->

<!-- Andoird App Development Process start-->
<section class="andoird-app-dev-process">
    <img src="images/ande.png" alt="" class="ande">
    <div class="container">
        <div class="heading">
            <h5>Explore</h5>
            <h2>Discover Our Methodical Mobile App Development Process</h2>
            <p>
                Our expert mobile app developers streamline a process that is carefully structured, with a primary focus
                on personalized user experiences and the creation of exceptionally efficient solutions. Through our
                comprehensive range of services, we establish a transparent and dependable partnership, ensuring the
                delivery of impactful and groundbreaking digital solutions. With our experienced guidance and
                never-ending dedication, you can trust us to navigate every aspect of the journey professionally and
                precisely, driving forward transformative results for your business.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <d iv class="flawless-digital-slider">
                    <div class="flawless-digital-slide">
                        <h6>Planning</h6>
                        <p>
                            With a clear understanding, we develop a detailed plan outlining the scope, timeline, and
                            resources required for the project.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Discovery</h6>
                        <p>
                            We begin by understanding your needs and goals and gathering essential information to lay
                            the foundation for our collaboration.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Design
                        </h6>
                        <p>
                            Our team creates intuitive, user-friendly designs, ensuring the app aligns seamlessly with
                            your vision and objectives.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Testing</h6>
                        <p>
                            Rigorous testing procedures are conducted to identify and resolve any issues, ensuring the
                            app meets high standards of quality and functionality.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Launch</h6>
                        <p>
                            Once thoroughly tested and approved, we deploy the software, providing comprehensive support
                            and guidance to ensure a smooth transition and optimal performance.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Development</h6>
                        <p>
                            Our skilled iOS app developers bring the designs to life, fla coding and building the app
                            according to the outlined specifications.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- Andoird App Development Process end-->

<!-- diversified sec start -->
<section class="diversified">
    <div class="container">
        <div class="text-center">
            <h2 class="py-3">Diversified Industry Experience</h2>
            <p>We’ve refined our custom app development expertise across diverse industries, including healthcare,
                finance, retail, media, hospitality, and more. Each has unique needs, which we address through tailored
                solutions focused on user experience and robust functionality. Review client examples from your specific
                vertical to learn how our custom mobile apps solve problems and create value. Let our experience work
                for you!
            </p>
        </div>
        <div class="row pt-5">
            <div class="col-12 col-lg-5 col-md-6 position-relative">
                <div class="Maps whiteInd">
                    <a href="#;">Maps & Navigation</a>
                </div>
                <div class="healthcare pinkInd">
                    <a href="#;">Healthcare</a>
                </div>
                <div class="event whiteInd">
                    <a href="#;">Event & Bookings</a>
                </div>
                <div class="logistics blackInd">
                    <a href="#;">Logistics</a>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 position-relative">
                <div class="social pinkInd">
                    <a href="#;">Social Networking</a>
                </div>
                <div class="entertainment blackInd">
                    <a href="#;">Entertainment</a>
                </div>
                <div class="education pinkInd">
                    <a href="#;">Education & Academics</a>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 position-relative">
                <div class="Food whiteInd">
                    <a href="#;">Food & Restaurant</a>
                </div>
                <div class="business whiteInd">
                    <a href="#;">Business & Finance</a>
                </div>
                <div class="travel blackInd">
                    <a href="#;">Travel & Hotel</a>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- diversified sec end -->


<!-- game Game-Changing start-->
<section class="game-changing">
    <div class="container">
        <div class="row">
            <div class="col-12 col-xl-10">
                <div class="py-5 game-changing-head">
                    <h5>Explore Our Portfolio</h5>
                    <h2>
                        Drive Innovation, Growth And Success With Top-Notch Mobile Application Development Services
                    </h2>
                    <p class="mt-2">
                        Our mobile app development experts deliver best-in-class solutions to meet business goals. With
                        expertise in both iOS and Android development, we help businesses leverage emerging technologies
                        to engage customers, boost efficiency and gain a strategic edge.
                    </p>
                    <p class="mt-3">
                        Every project gets a dedicated team that understands your needs and workflow. From concept to
                        launch and beyond, we ensure apps are seamlessly integrated with your overall digital presence
                        for maximum impact.
                    </p>
                    <p>
                        Contact us to discuss how to accelerate growth through custom mobile app development services.
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-4 col-md-6 mb-5 p-0">
                <div class="game-changing-col">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>
                        Custom Mobile App
                        Development
                    </h6>
                    <p>
                        We will work closely with you every step of the way, from concept development to design to
                        building and testing, to create a fully customized native mobile app solution tailored precisely
                        to your unique business needs, goals, workflows and target users. Our dedicated team of
                        developers will ensure the app integrates seamlessly with the rest of your tech systems and
                        digital presence.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 p-0">
                <div class="game-changing-col game-changing-col-acti">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>
                        Mobile Web App
                        Development
                    </h6>
                    <p>
                        For clients who want the reach and accessibility of a responsive mobile experience without
                        device-specific native apps, we design and code high performing, secure progressive web apps
                        that can be easily updated and accessed across iOS and Android devices, as well as tablets and
                        other mobile platforms. Our mobile web apps load fast and have native app capabilities.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 p-0">
                <div class="game-changing-col">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>
                        Mobile App Maintenance
                        and Support
                    </h6>
                    <p>
                        Even after an initial successful app launch, ongoing maintenance and improvements are required
                        to keep up with evolving technologies, fix bugs, add features and ensure optimal performance. We
                        offer comprehensive support programs so you can focus on your business while we handle regular
                        updates and troubleshooting to keep your apps fully optimized throughout their lifecycle.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- seamless mobile exp end-->

<!-- Andoird App Development Process start-->
<section class="andoird-app-dev-process">
    <img src="images/ande.png" alt="" class="ande">
    <div class="container">
        <div class="heading">
            <h5>Explore</h5>
            <h2>Why Opt For Custom Mobile App Development Services For Your Business?</h2>
            <p>
                With mobile usage constantly rising, a custom app is essential to engage customers anywhere, anytime on
                their preferred devices. An app tailored specifically for your business needs and brand allows far
                deeper engagement and functionality compared to basic website access. You can create seamless
                experiences, automate processes, and gain valuable usage insights. An app also strengthens your
                competitive positioning by delivering a consistently superior digital service. Opting for expert
                development services ensures quality and compliance from project scoping through ongoing support. The
                result? Increased customer loyalty, conversion rates and data-driven strategic advantages.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <d iv class="flawless-digital-slider">
                    <div class="flawless-digital-slide">
                        <h6>
                            Cost-Efficient
                            Development
                        </h6>
                        <p>
                            Maximize cost-efficiency by targeting multiple platforms with Flutter. Reduce development
                            and maintenance expenses while delivering high-quality, cross-platform app solutions
                            tailored to your business needs.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Unlock a Global
                            Audience
                        </h6>
                        <p>
                            Android apps broaden your market horizon, connecting you with a diverse global audience and
                            extending your reach beyond borders.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Customized Native
                            App Development
                        </h6>
                        <p>
                            By deeply understanding your business goals and target users, we develop high-performing,
                            fully-customized native apps for iOS and Android that are seamlessly integrated into your
                            overall brand experience and digital strategy.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Progressive Web
                            App Creation</h6>
                        <p>
                            We design and code next-level PWAs that are lightning fast, safe and reliable, with app-like
                            capabilities that improve user experience and drive continual engagement through regular
                            updates and new features.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Native App Integration
                        </h6>
                        <p>
                            We ensure seamless integration of your custom mobile experience with existing digital
                            properties, backend systems and third party services through secure APIs and other
                            interfaces.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            App Lifecycle Management
                        </h6>
                        <p>
                            Ongoing maintenance by our team keeps apps optimized over time, with quick and reliable bug
                            fixes, performance enhancements, new features and compliance with emerging standards.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
            </div>
        </div>
    </div>
</section>
<!-- Andoird App Development Process end-->

<!-- our mission sec start -->
<section class="our-mission">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <img src="images/cust-mob2.png" alt="">
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div class="txt1">
                    <h2>
                        Our Mission - Empowering Your Journey With Innovation & Integrity
                    </h2>
                    <p>
                        At our core, our mission is to empower businesses with transformative digital solutions that
                        drive growth and innovation. We are dedicated to leveraging our expertise and creativity to
                        craft bespoke digital products that meet the unique needs and challenges of each client.
                    </p>
                    <p class="mt-2">
                        Our commitment to excellence guides every aspect of our work, from initial concept to final
                        delivery. We prioritize transparency, communication, and collaboration to ensure that our
                        clients are always informed and involved throughout the web application development process. By
                        fostering strong partnerships built on trust and reliability, we aim to become the go-to digital
                        partner for businesses seeking to thrive in today’s competitive landscape.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div class="txt2">
                    <h2>
                        What Makes The Praetors Your Ideal Mobile Application Development Company?
                    </h2>
                    <p>
                        With over two decades of experience in the indutry, The Praetors have established a reputation
                        as a
                        premier custom mobile application development services provider through our deep technical
                        expertise
                        and track record of successful projects.
                    </p>
                    <p>
                        Our talented team approaches each client solution with care, thoroughness and an unmatched
                        understanding of app frameworks, standards and runtime capabilities. By prioritizing
                        architectural
                        quality, performance optimization and accessibility, we develop robust, feature-rich apps that
                        exceed user expectations.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <img src="images/cust-mob3.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- our mission sec end -->

<!-- Andoird App Development Process start-->
<section class="andoird-app-dev-process">
    <img src="images/ande.png" alt="" class="ande">
    <div class="container">
        <div class="heading">
            <h5>Explore</h5>
            <h2>Why Opt For Custom Web Development For Your Business?</h2>
            <p>
                There are numerous reasons to pursue a strategic investment in custom web application development. A
                solution purpose-built around your unique requirements will optimize key functions to drive
                efficiencies. Integration of proprietary data sources enables actionable insight. Additionally,
                customizing the user experience strengthens your brand and relationships.
            </p>
            <p class="mt-2">
                Our process focuses on goals like increased revenue, reduced costs, and sustained competitive
                differentiation. Overall, a tailored digital platform can substantially elevate organizational
                performance.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <d iv class="flawless-digital-slider">
                    <div class="flawless-digital-slide">
                        <h6>
                            Future Growth
                            Capabilities
                        </h6>
                        <p>
                            Innovative features keep your app aligned with evolving needs while its flexibility supports
                            business transformations.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Increased Operational
                            Efficiency
                        </h6>
                        <p>
                            A tailored solution streamlines complex workflows to save time and resources through
                            automation and integration.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Enhanced Customer
                            Experience
                        </h6>
                        <p>
                            Customizing interactions based on research builds loyalty by satisfying precise needs
                            through an intuitive, consistent experience.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Actionable Business
                            Insights</h6>
                        <p>
                            Integrating diverse internal and external data sources unleashes customized analytics to
                            reveal patterns that guide strategic decisions.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Stronger Brand Identity
                        </h6>
                        <p>
                            Incorporating your unique messaging, look and feel establishes a consistent digital presence
                            that deepens customer relationships.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Future Growth Capabilities
                        </h6>
                        <p>
                            Innovative features keep your app aligned with evolving needs while its flexibility supports
                            business transformations.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
            </div>
        </div>
    </div>
</section>
<!-- Andoird App Development Process end-->

<!-- perks-of-working start -->
<section class="perks-of-working">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div class="text-center">
                    <h5>Explore</h5>
                    <h2 class="py-2">
                        Benefits Of Working With A Professional & Reliable Custom Mobile App Development Services
                        Provider
                    </h2>
                    <p>
                        When you collaborate with The Praetors, a top-rated iOS app development company, you unlock a
                        pathway to accelerated business growth. Our innovative services offer a multitude of benefits
                        that can maneuver your business forward, ensuring success in the competitive market landscape.
                    </p>
                </div>
            </div>
        </div>
        <div class="row pt-5">
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks1.jpg" alt="">
                    <div>
                        <h6>
                            Future-Ready Products
                        </h6>
                        <p>
                            We're all about staying ahead of the game, crafting innovative solutions that'll tackle
                            tomorrow’s challenges head-on.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks2.png" alt="">
                    <div>
                        <h6>
                            Dedicated Team
                        </h6>
                        <p>
                            Count on us to bring your ideas to life! Our Android app developers are dedicated, skilled,
                            and ready to make your vision a reality.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks3.jpg" alt="">
                    <div>
                        <h6>
                            Customer Experience
                        </h6>
                        <p>
                            We’re here to make your experience seamless and personalized, tailored just for you and your
                            success.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks4.jpg" alt="">
                    <div>
                        <h6>
                            Satisfaction Guarantee
                        </h6>
                        <p>
                            Your satisfaction is our top priority. We're committed to making sure you're thrilled with
                            the results.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- perks-of-working end -->


<!-- faqs sec start -->
<section class="faqs-sec">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-9">
                <div>
                    <div class="text-center py-5">
                        <h2>custom mobile App Development FAQs
                        </h2>
                    </div>
                    <div class="faq-accordian-sec">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. How long does it take to develop an Android app?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            The time required to develop an Android app varies based on its complexity,
                                            features, and customization needs. Typically, it can take anywhere from a
                                            few weeks to several months.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. What factors influence the cost of Android app development?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Several factors impact the cost, including the app’s complexity, features,
                                            design, development hours, testing, maintenance, and post-launch support
                                            requirements.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. Do I need to have technical knowledge to develop an Android app?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            While technical knowledge can be helpful, it’s not mandatory. Working with a
                                            professional Android app development company allows you to bring your ideas
                                            to life without the need for extensive technical expertise.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFour" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        4. How do you ensure the security of Android apps?
                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            We prioritize security throughout the development process, implementing best
                                            practices for data encryption, secure authentication, and robust
                                            authorization mechanisms to safeguard user data and prevent unauthorized
                                            access.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFive" aria-expanded="false"
                                        aria-controls="collapseFive">
                                        5. Can you assist with publishing the app on the Google Play Store?
                                    </button>
                                </h2>
                                <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Yes, we provide comprehensive support, including assistance with app store
                                            submission, compliance with Google Play Store guidelines, and optimization
                                            of app listings for maximum visibility and reach.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                        6. Do you offer ongoing maintenance and support for Android apps?
                                    </button>
                                </h2>
                                <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Absolutely. We offer maintenance and support services post-launch to ensure
                                            your app remains up-to-date, secure, and optimized for performance. Our team
                                            is available to address any issues, implement updates, and provide technical
                                            assistance as needed.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="message-box">
                    <ul>
                        <li>
                            <img src="images/message.png" alt="">
                            <h5>Do you have any other <br> question?</h5>
                        </li>
                        <li>
                            <a href="" class="btn1">
                                Get Started <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- faqs sec end -->


<!-- client-say start -->
<section class="client-say">
    <div class="container">
        <div class="heading">
            <h5>Testimonials</h5>
            <h2>What Our client say’s</h2>
            <p>
                Hear first-hand from satisfied clients how our AI/ML development services have delivered tangible
                results. Glowing reviews highlight transformed operations through streamlined processes, increased
                revenues from predictive insights, and deepened relationships underpinned by personalized engagements.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="client-say-slider">
                    <div class="client-say-slide">
                        <img src="images/client1.png" alt="" class="pers">
                        <img src="images/client6.png" alt="">
                        <p>
                            The Praetors' customized demand forecasting model far exceeded our expectations. Inventory
                            is perfectly aligned with sales patterns, slashing carrying costs by 20%. I'm impressed by
                            their expertise and professionalism.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Natalia Owens</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client2.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            Since implementing their recommendation engine, our website visits are up 30% as visitors
                            consistently find highly relevant products. Their intuitive dashboard provides insights to
                            constantly refine our strategies. It's clear they truly understand our business.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Thomas Sylvester</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client3.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            As a manufacturing firm striving for efficiency, The Praetors' quality control AI eliminated
                            defect rates and sped up our production line. With their optimized predictive maintenance
                            system, downtime has been reduced to almost zero. Their solutions clearly produce measurable
                            results for us on the factory floor.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Jacob Vasquez</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client4.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            The team at The Core Designs listened to everything we wanted in a new website before
                            building it! Our new website is dynamic, fascinating, and straightforward to use for
                            both myself and our viewers. This was by far the smoothest and least painful website
                            change I've ever experienced. I was heard and valued every step of the way. Our new
                            website has surpassed all of our expectations.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Mike</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- client-say end -->


<!-- work together start -->
<section class="work-toether">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <h5>LET'S WORK TOGETHER</h5>
                    <h2>
                        We're Here <br>
                        To Make It Happen
                    </h2>
                    <p>
                        Join forces with us to bring your digital product visions to life. Let's ignite the spark of
                        innovation and create something truly extraordinary.
                    </p>
                    <img src="images/work1.png" alt="">
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <form action="">
                    <div class="row">
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Your Name" class="form-label">Your Name</label>
                                <input type="text" id="Your Name" class="form-control" placeholder="Enter your name">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Your Email" class="form-label">Your Email</label>
                                <input type="text" id="Your Email" placeholder="Enter your email" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Company" class="form-label">Company</label>
                                <input type="text" id="Company" placeholder="Company name" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Business Name" class="form-label">Message</label>
                                <textarea name="" id="" placeholder="Write your message"
                                    class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="btn1">
                                Send Message
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- work together end -->



<?php
include 'includes/footer.php';
$page = 'home';
?>