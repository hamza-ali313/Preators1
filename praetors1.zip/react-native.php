<?php
$page = 'Home';
$pageDesc = '""';
include 'includes/header1.php';
?>


<!-- Inner banner sec start -->
<section class="inner-banner">
    <img src="images/inner-bg1.png" alt="" class="inner-bg1">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-7 col-md-12">
                <div>
                    <h5>Home > Services > Cross-Platform App Development </h5>
                    <h1>No. 1 React Native App Development Company In USA</h1>
                    <p>
                        For top-tier React Native app development solutions, The Praetors is the perfect partner for
                        you. As a leading React Native app development services providers in the US, we deliver
                        world-class services tailored to meet your unique needs. With extensive experience and expertise
                        in mobile app development, our team ensures excellence in utilizing React Native and other
                        cutting-edge frameworks to bring your app ideas to life.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-5 col-md-12">
                <div>
                    <img src="images/reactnative-bn.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Inner banner sec end -->

<!-- partner with sec start -->
<section class="partner-with">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8 col-md-8">
                <div>
                    <img src="images/reactnative1.png" alt="" class="and1">
                    <h2>Partner With Top-Rated React Native Mobile App Development Company For Seamless,
                        Fully-Functional Apps!</h2>
                    <p>
                        React Native simplifies native app development, offering advanced capabilities for handling
                        multimedia data. Integrated with CSS or JavaScript, it boosts performance and provides semantic
                        elements. Companies opt for React Native to streamline cross-platform app implementation,
                        reducing costs and complexity.
                        With its platform-agnostic framework, React Native enables "write once, run anywhere"
                        convenience. Our expertise in React Native app development ensures powerful hybrid mobile apps
                        with enhanced performance, capabilities, and responsiveness for your next project.
                    </p>
                    <a href="" class="btn1">
                        Lets Build Your Android App Now
                    </a>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 col-md-4 ps-3">
                <div class="our-serv-headings">
                    <h6>Our Services</h6>
                    <ul>
                        <li class="active">
                            <a href="">
                                <h5>Android App Development</h5>
                                <h5>(2)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>iOS App Development</h5>
                                <h5>(2)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>Digital solutions</h5>
                                <h5>(3)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>strategy & Research</h5>
                                <h5>(4)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>Business Model</h5>
                                <h5>(3)</h5>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="ready-to-help">
                    <img src="images/and2.jpg" alt="" class="and2">
                    <div>
                        <img src="images/logo.png" alt="">
                        <h6>
                            We’re Always ready
                            for help You
                        </h6>
                        <a href="" class="btn1">Need Help <i class="far fa-chevron-double-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- partner with sec end -->

<!-- connect with audience start -->
<section class="con-audience">
    <img src="images/reactnative4.png" alt="" class="seamless-bg reactnative4">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-12 ">
                <div class="heading">
                    <h2>
                        When To Consider Our Robust React Native App Development Services
                    </h2>
                    <p>
                        Explore our robust React Native app development services when you're ready to strengthen your
                        digital presence. Our expertise ensures seamless cross-platform solutions that cater to your
                        unique business needs, empowering you to reach a broader audience and achieve your goals
                        effectively.Top of Form
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-12 col-lg-4 col-md-6 mb-5 col-md-6">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Cross-Platform
                        Compatibility
                    </h4>
                    <p>
                        Our React Native app development ensures your app functions seamlessly on both iOS and Android
                        platforms, utilizing a single codebase. This feature minimizes development time and costs while
                        maximizing reach and user accessibility across different devices.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 col-md-6">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Native Performance
                    </h4>
                    <p>
                        Leveraging React Native's ability to compile code directly to native components, we deliver apps
                        with near-native performance. Users experience swift interactions and responsive interfaces,
                        enhancing overall satisfaction and engagement with your application.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 col-md-6">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Rapid Development
                    </h4>
                    <p>
                        With React Native's hot reload feature, our developers can make real-time changes to the app's
                        codebase, enabling rapid iterations and updates. This agile development approach accelerates the
                        development cycle, allowing for quicker time-to-market and increased flexibility in responding
                        to user feedback.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- connect with audience end -->



<!-- technologies sec start -->
<section class="tech-sec ande-tech-sec">
    <div class="container">
        <div class="text-center mb-5 pb-3">
            <h2>
                Innovative Ecommerce Mobile App Development, Driven By Dynamic Tech Stacks
            </h2>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="tech-slider pt-5">
                    <div class="tech-slide">
                        <img src="images/tec1.png" alt="" class="tec1">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec2.png" alt="" class="tec2">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec3.png" alt="" class="tec3">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec4.png" alt="" class="tec4">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec5.png" alt="" class="tec5">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec6.png" alt="" class="tec6">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec7.png" alt="" class="tec7">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec17.png" alt="" class="tec17">
                    </div>
                </div>
                <div class="tech-slider1 pt-5">
                    <div class="tech-slide">
                        <img src="images/tec9.png" alt="" class="tec15">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec10.png" alt="" class="tec10">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec11.png" alt="" class="tec11">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec12.png" alt="" class="tec12">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec13.png" alt="" class="tec13">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec14.png" alt="" class="tec14">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec15.png" alt="" class="tec15">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec16.png" alt="" class="tec16">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec17.png" alt="" class="tec17">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- technologies sec end -->

<!-- Andoird App Development Process start-->
<section class="andoird-app-dev-process">
    <img src="images/ande.png" alt="" class="ande">
    <div class="container">
        <div class="heading">
            <h5>Explore</h5>
            <h2>Our Seamless React Native App Development Process</h2>
            <p>
                Experience a streamlined React Native app development process for guaranteed efficiency and excellence.
                From conception to deployment, our team guides you through planning, design, development, and testing,
                ensuring top-notch results. Partner with us for a hassle-free journey from idea to reality, backed by
                industry expertise and unwavering commitment to quality.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <d iv class="flawless-digital-slider">
                    <div class="flawless-digital-slide">
                        <h6>Planning</h6>
                        <p>
                            With a clear understanding, we develop a detailed plan outlining the scope, timeline, and
                            resources required for the project.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Discovery</h6>
                        <p>
                            We begin by understanding your needs and goals and gathering essential information to lay
                            the foundation for our collaboration.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Design
                        </h6>
                        <p>
                            Our team creates intuitive, user-friendly designs, ensuring the app aligns seamlessly with
                            your vision and objectives.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Testing</h6>
                        <p>
                            Rigorous testing procedures are conducted to identify and resolve any issues, ensuring the
                            app meets high standards of quality and functionality.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Launch</h6>
                        <p>
                            Once thoroughly tested and approved, we deploy the software, providing comprehensive support
                            and guidance to ensure a smooth transition and optimal performance.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Development</h6>
                        <p>
                            Our skilled iOS app developers bring the designs to life, fla coding and building the app
                            according to the outlined specifications.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- Andoird App Development Process end-->

<!-- diversified sec start -->
<section class="diversified">
    <div class="container">
        <div class="text-center">
            <h2 class="py-3">Diversified Industry Experience</h2>
            <p>We’ve refined our custom app development expertise across diverse industries, including healthcare,
                finance, retail, media, hospitality, and more. Each has unique needs, which we address through tailored
                solutions focused on user experience and robust functionality. Review client examples from your specific
                vertical to learn how our custom mobile apps solve problems and create value. Let our experience work
                for you!
            </p>
        </div>
        <div class="row pt-5">
            <div class="col-12 col-lg-5 col-md-6 position-relative">
                <div class="Maps whiteInd">
                    <a href="#;">Maps & Navigation</a>
                </div>
                <div class="healthcare pinkInd">
                    <a href="#;">Healthcare</a>
                </div>
                <div class="event whiteInd">
                    <a href="#;">Event & Bookings</a>
                </div>
                <div class="logistics blackInd">
                    <a href="#;">Logistics</a>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 position-relative">
                <div class="social pinkInd">
                    <a href="#;">Social Networking</a>
                </div>
                <div class="entertainment blackInd">
                    <a href="#;">Entertainment</a>
                </div>
                <div class="education pinkInd">
                    <a href="#;">Education & Academics</a>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 position-relative">
                <div class="Food whiteInd">
                    <a href="#;">Food & Restaurant</a>
                </div>
                <div class="business whiteInd">
                    <a href="#;">Business & Finance</a>
                </div>
                <div class="travel blackInd">
                    <a href="#;">Travel & Hotel</a>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- diversified sec end -->


<!-- game Game-Changing start-->
<section class="game-changing">
    <div class="container">
        <div class="row">
            <div class="col-12 col-xl-10">
                <div class="py-5 game-changing-head">
                    <h2>
                        Our Results-Driven React Native App Development Approach
                    </h2>
                    <p class="mt-2">
                        Discover the efficiency of our results-oriented React Native app development solutions. With a
                        focus on delivering measurable results, we power up our advanced methodologies and cutting-edge
                        tools to create bespoke applications that align with your strategic objectives.
                    </p>
                    <p class="mt-3">
                        From focused planning to flawless execution, our team is dedicated to driving impactful outcomes
                        for your business. Strengthen your digital presence with our professional React Native app
                        development services.
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-4 col-md-6 mb-5 col-md-6 p-0 ">
                <div class="game-changing-col">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>
                        Full Development Cycle
                    </h6>
                    <p>
                        Partner with The Praetors, a leading React Native mobile app development company, for end-to-end
                        development services. From initial design to testing and ongoing support, we cater to startups,
                        enterprises, and entrepreneurs, elevating your business with bespoke solutions.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 col-md-6 p-0">
                <div class="game-changing-col game-changing-col-acti">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>
                        MVP Development
                    </h6>
                    <p>
                        Unlock the full potential of your app idea with our expert React Native MVP development
                        services. Our team specializes in crafting minimum viable products that perfectly align with
                        your business goals and user expectations, ensuring rapid validation and market success.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 col-md-6 p-0">
                <div class="game-changing-col">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>
                        React Native App
                        Consultation
                    </h6>
                    <p>
                        Benefit from our team's extensive experience and insights with comprehensive React Native app
                        consultation services. We provide in-depth analysis, strategic planning, and actionable
                        recommendations to help you make informed decisions and achieve your app development objectives.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- seamless mobile exp end-->

<!-- Andoird App Development Process start-->
<section class="andoird-app-dev-process">
    <img src="images/ande.png" alt="" class="ande">
    <div class="container">
        <div class="heading">
            <h5>Explore</h5>
            <h2>Perks Of Our React Native App Development For Your Business Digitization</h2>
            <p>
                Experience the transformative benefits of our React Native app development services for your business
                digitization journey. Our expert team harnesses the power of React Native to create high-performance,
                cross-platform apps that boost your brand visibility and drive growth. With streamlined development
                processes and innovative solutions, we deliver scalable and user-friendly apps tailored to meet your
                specific business needs and objectives.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="flawless-digital-slider">
                    <div class="flawless-digital-slide">
                        <h6>
                            Cross-Platform
                            Compatibility
                        </h6>
                        <p>
                            Progressive web apps can be accessed on any device via a URL, without requiring native app
                            downloads or app store approvals. This cross-platform reach allows your app to work
                            seamlessly across different operating systems.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Cost-Efficiency
                        </h6>
                        <p>
                            Optimized code, efficient resource caching, and service workers help progressive web apps
                            load instantly even on slow mobile connections. Automatic caching of resources and static
                            assets further enhances responsiveness and provides fast performance for users.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Rapid Development
                        </h6>
                        <p>
                            Benefit from our accelerated development process enabled by React Native's hot reload
                            feature, allowing real-time code changes and faster iterations to bring your app to market
                            quickly.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Native Performance</h6>
                        <p>
                            Enjoy near-native performance with React Native apps, as they are compiled to native code,
                            providing smooth and responsive user experiences across devices.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Enhanced User Experience
                        </h6>
                        <p>
                            We prioritize user experience in our React Native app development, crafting intuitive
                            interfaces and engaging features that captivate users and drive retention rates.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
</section>
<!-- Andoird App Development Process end-->

<!-- our mission sec start -->
<section class="our-mission">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <img src="images/reactnative2.png" alt="">
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div class="txt1">
                    <h2>
                        Our Mission - Empowering Your Journey With Innovation & Integrity
                    </h2>
                    <p>
                        At our core, our mission is to empower businesses with transformative digital solutions that
                        drive growth and innovation. We are dedicated to leveraging our expertise and creativity to
                        craft bespoke digital products that meet the unique needs and challenges of each client.
                    </p>
                    <p class="mt-2">
                        Our commitment to excellence guides every aspect of our work, from initial concept to final
                        delivery. We prioritize transparency, communication, and collaboration to ensure that our
                        clients are always informed and involved throughout the web application development process. By
                        fostering strong partnerships built on trust and reliability, we aim to become the go-to digital
                        partner for businesses seeking to thrive in today’s competitive landscape.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div class="txt2">
                    <h2>
                        Choosing The Praetors As Your Trusted React Native App Development Company
                    </h2>
                    <p>
                        Partnering with The Praetors for your React Native app development needs offers several
                        advantages. Firstly, we possess extensive knowledge of both traditional and emerging
                        technologies, ensuring we employ the most suitable technology stack and agile methodologies for
                        your project.
                    </p>
                    <p>
                        Secondly, we boast a team of elite React Native app development pros and QA engineers dedicated
                        to ensuring the performance and scalability of your digital assets.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <img src="images/reactnative3.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- our mission sec end -->

<!-- perks-of-working start -->
<section class="perks-of-working">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div class="text-center">
                    <h5>Explore</h5>
                    <h2 class="py-2">
                        Benefits Of Partnering With The Praetors – Top Game App Development Company In USA
                    </h2>
                    <p>
                        Our expertise and dedication ensure top-notch solutions meeting your business’s unique needs.
                        Experience our immaculate approach, streamlined processes, and commitment to perfection, lifting
                        your business to the top in the competitive gaming industry. Choose The Praetors for
                        unparalleled quality and success in game app development.
                    </p>
                </div>
            </div>
        </div>
        <div class="row pt-5">
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks1.jpg" alt="">
                    <div>
                        <h6>
                            Future-Ready Products
                        </h6>
                        <p>
                            We're all about staying ahead of the game, crafting innovative solutions that'll tackle
                            tomorrow’s challenges head-on.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks2.png" alt="">
                    <div>
                        <h6>
                            Dedicated Team
                        </h6>
                        <p>
                            Count on us to bring your ideas to life! Our Android app developers are dedicated, skilled,
                            and ready to make your vision a reality.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks3.jpg" alt="">
                    <div>
                        <h6>
                            Customer Experience
                        </h6>
                        <p>
                            We’re here to make your experience seamless and personalized, tailored just for you and your
                            success.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks4.jpg" alt="">
                    <div>
                        <h6>
                            Satisfaction Guarantee
                        </h6>
                        <p>
                            Your satisfaction is our top priority. We're committed to making sure you're thrilled with
                            the results.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- perks-of-working end -->


<!-- faqs sec start -->
<section class="faqs-sec">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div>
                    <div class="text-center py-5">
                        <h2>React Native Mobile App Development FAQs</h2>
                    </div>
                    <div class="faq-accordian-sec">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                        1. What is React Native and why should I choose it for my mobile app?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne"
                                    data-bs-parent="#accordionExample" style="">
                                    <div class="accordion-body">
                                        <p>
                                            React Native is a framework developed by Facebook for building mobile
                                            applications using JavaScript and React. It allows for the creation of
                                            cross-platform apps, meaning the same codebase can be used for both iOS and
                                            Android, saving time and resources.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can React Native apps be published on both iOS and Android platforms?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExample" style="">
                                    <div class="accordion-body">
                                        <p>
                                            Yes, React Native apps can be published on both iOS and Android platforms.
                                            React Native uses a single codebase, allowing developers to write once and
                                            deploy on multiple platforms.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take to develop a React Native mobile app?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            The time it takes to develop a React Native mobile app can vary depending on
                                            the complexity of the project, features required, and the development team's
                                            experience. Typically, development timelines can range from a few weeks to
                                            several months.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFour" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        4. What are the key advantages of using React Native for app development?
                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Some key advantages of using React Native include faster development time,
                                            cost-effectiveness, a large developer community, and the ability to create
                                            cross-platform apps with a single codebase.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFive" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        5. Do I need separate development teams for iOS and Android with React Native?
                                    </button>
                                </h2>
                                <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            No, one of the main advantages of React Native is that it allows for the
                                            development of cross-platform apps with a single codebase. This means you
                                            can use the same development team to build apps for both iOS and Android
                                            platforms.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseSix" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        6. How does The Praetors ensure the security of React Native apps during
                                        development?
                                    </button>
                                </h2>
                                <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            At The Praetors, we prioritize the security of our clients' apps. We follow
                                            industry best practices for secure coding, conduct regular security audits,
                                            and implement measures such as data encryption and secure authentication to
                                            ensure the security of React Native apps during development.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="message-box">
                    <ul>
                        <li>
                            <img src="images/message.png" alt="">
                            <h5>Do you have any other <br> question?</h5>
                        </li>
                        <li>
                            <a href="" class="btn1">
                                Get Started <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- faqs sec end -->


<!-- client-say start -->
<section class="client-say">
    <div class="container">
        <div class="heading">
            <h5>Testimonials</h5>
            <h2>What Our client say’s</h2>
            <p>
                Hear first-hand from satisfied clients how our AI/ML development services have delivered tangible
                results. Glowing reviews highlight transformed operations through streamlined processes, increased
                revenues from predictive insights, and deepened relationships underpinned by personalized engagements.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="client-say-slider">
                    <div class="client-say-slide">
                        <img src="images/client1.png" alt="" class="pers">
                        <img src="images/client6.png" alt="">
                        <p>
                            The Praetors' customized demand forecasting model far exceeded our expectations. Inventory
                            is perfectly aligned with sales patterns, slashing carrying costs by 20%. I'm impressed by
                            their expertise and professionalism.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Natalia Owens</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client2.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            Since implementing their recommendation engine, our website visits are up 30% as visitors
                            consistently find highly relevant products. Their intuitive dashboard provides insights to
                            constantly refine our strategies. It's clear they truly understand our business.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Thomas Sylvester</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client3.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            As a manufacturing firm striving for efficiency, The Praetors' quality control AI eliminated
                            defect rates and sped up our production line. With their optimized predictive maintenance
                            system, downtime has been reduced to almost zero. Their solutions clearly produce measurable
                            results for us on the factory floor.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Jacob Vasquez</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client4.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            The team at The Core Designs listened to everything we wanted in a new website before
                            building it! Our new website is dynamic, fascinating, and straightforward to use for
                            both myself and our viewers. This was by far the smoothest and least painful website
                            change I've ever experienced. I was heard and valued every step of the way. Our new
                            website has surpassed all of our expectations.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Mike</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- client-say end -->


<!-- work together start -->
<section class="work-toether">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <h5>LET'S WORK TOGETHER</h5>
                    <h2>
                        We're Here <br>
                        To Make It Happen
                    </h2>
                    <p>
                        Join forces with us to bring your digital product visions to life. Let's ignite the spark of
                        innovation and create something truly extraordinary.
                    </p>
                    <img src="images/work1.png" alt="">
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <form action="">
                    <div class="row">
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Your Name" class="form-label">Your Name</label>
                                <input type="text" id="Your Name" class="form-control" placeholder="Enter your name">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Your Email" class="form-label">Your Email</label>
                                <input type="text" id="Your Email" placeholder="Enter your email" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Company" class="form-label">Company</label>
                                <input type="text" id="Company" placeholder="Company name" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Business Name" class="form-label">Message</label>
                                <textarea name="" id="" placeholder="Write your message"
                                    class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="btn1">
                                Send Message
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- work together end -->



<?php
include 'includes/footer.php';
$page = 'home';
?>