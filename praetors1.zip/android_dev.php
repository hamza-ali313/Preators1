<?php
$page = 'Home';
$pageDesc = '""';
include 'includes/header1.php';
?>


<!-- Inner banner sec start -->
<section class="inner-banner">
    <img src="images/inner-bg1.png" alt="" class="inner-bg1">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-7 col-md-12">
                <div>
                    <h1>Android App Development</h1>
                    <p>
                        In today's fast-paced digital landscape, Android apps play a pivotal role in connecting
                        businesses with their target audience. The Praetors is a professional Android application
                        development agency in the USA that excels in crafting bespoke mobile apps that cater to our
                        clients' unique needs and aspirations. Our comprehensive Android app development services are
                        tailored to leverage the full potential of the Android platform and deliver exceptional user
                        experiences.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-5 col-md-12 ">
                <div>
                    <img src="images/android1.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Inner banner sec end -->

<!-- partner with sec start -->
<section class="partner-with">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div>
                    <img src="images/and1.jpg" alt="" class="and1">
                    <h2>Partner with Custom Android App Development Company for Robust</h2>
                    <p>
                        We understand that each business has its own set of objectives and challenges. That's why we
                        take
                        a personalized approach to Android app development, starting with a thorough analysis of our
                        clients' requirements and goals.
                        Our team works closely with clients to conceptualize, design, and develop custom Android
                        applications that resonate with their brand identity and meet the demands of their target
                        market.
                    </p>
                    <a href="" class="btn1">
                        Lets Build Your Android App Now
                    </a>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 ps-3">
                <div class="our-serv-headings">
                    <h6>Our Services</h6>
                    <ul>
                        <li class="active">
                            <a href="">
                                <h5>Android App Development</h5>
                                <h5>(2)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>iOS App Development</h5>
                                <h5>(2)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>Digital solutions</h5>
                                <h5>(3)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>strategy & Research</h5>
                                <h5>(4)</h5>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <h5>Business Model</h5>
                                <h5>(3)</h5>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="ready-to-help">
                    <img src="images/and2.jpg" alt="" class="and2">
                    <div>
                        <img src="images/logo.png" alt="">
                        <h6>
                            We’re Always ready
                            for help You
                        </h6>
                        <a href="" class="btn1">Need Help <i class="far fa-chevron-double-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- partner with sec end -->

<!-- connect with audience start -->
<section class="con-audience">
    <img src="images/seamless-bg.png" alt="" class="seamless-bg">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="heading">
                    <h2>Seamlessly Connect With Your Audience Through Our Android App Development Services</h2>
                    <p>
                        Backed by a team of seasoned Android app developers, we bring expertise and creativity to every
                        project we undertake. From crafting clean and efficient code to implementing innovative
                        features, our developers ensure that each app we deliver is of the highest quality.
                        With a focus on usability, performance, and security, we strive to exceed our clients'
                        expectations and deliver solutions that make an impact.
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-12 col-lg-4 col-md-6 mb-5">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Cross-Platform
                        Compatibility
                    </h4>
                    <p>
                        Ensure seamless performance across various platforms, including iOS and Android, to reach a
                        broader audience base. Expand your app's accessibility and maximize user engagement with
                        consistent experiences on all devices.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Customizable <br>
                        User Interface
                    </h4>
                    <p>
                        Tailor your app's design and layout to reflect your brand identity and resonate with your target
                        audience. From color schemes to navigation menus, offer a personalized user experience that
                        fosters brand recognition and user satisfaction.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5">
                <div class="con-box">
                    <img src="images/con1.png" alt="">
                    <h4>
                        Robust Security <br>
                        Measures
                    </h4>
                    <p>
                        Implement advanced security protocols and encryption techniques to safeguard user data and
                        protect against cyber threats. Prioritize user privacy and build trust by ensuring that your app
                        adheres to industry standards for data protection and secure transactions.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- connect with audience end -->

<!-- seamless mobile exp start-->
<section class="mobile_exp">
    <div class="container">
        <div class="row">
            <div class="col-12 col-xl-10">
                <div class="heading_section aos-init aos-animate" data-aos="fade-right" data-aos-duration="3000">
                    <h5>Explore Our Portfolio</h5>
                    <h2>Seamless Mobile App Experience</h2>
                    <p>Our project portfolio showcases the diverse array of innovative mobile and web apps we've
                        developed for organizations worldwide. Each case study highlights how our end-to-end services
                        and technical expertise bring ambitious ideas to market and deliver tangible business impact
                        through digital solutions tailored to our clients' needs. Peruse the portfolio to see examples
                        of stunning UX design, smooth functionality, and platform-optimized performance across
                        industries. Let the work speak for itself!
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-7 col-md-6">
                <div>
                    <img src="images/seam1.png" alt="" class="mobile_exp-img1">
                    <img src="images/seam3.png" alt="" class="mobile_exp-img2">
                </div>
            </div>
            <div class="col-12 col-lg-5 col-md-6">
                <div>
                    <img src="images/seam2.png" alt="" class="mobile_exp-img3">
                    <img src="images/seam4.png" alt="" class="mobile_exp-img4">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- seamless mobile exp end-->


<!-- technologies sec start -->
<section class="tech-sec ande-tech-sec">
    <div class="container">
        <div class="text-center mb-5 pb-3">
            <h2>Technologies And Platforms We Use</h2>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="tech-slider pt-5">
                    <div class="tech-slide">
                        <img src="images/tec1.png" alt="" class="tec1">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec2.png" alt="" class="tec2">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec3.png" alt="" class="tec3">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec4.png" alt="" class="tec4">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec5.png" alt="" class="tec5">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec6.png" alt="" class="tec6">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec7.png" alt="" class="tec7">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec17.png" alt="" class="tec17">
                    </div>
                </div>
                <div class="tech-slider1 pt-5">
                    <div class="tech-slide">
                        <img src="images/tec9.png" alt="" class="tec15">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec10.png" alt="" class="tec10">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec11.png" alt="" class="tec11">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec12.png" alt="" class="tec12">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec13.png" alt="" class="tec13">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec14.png" alt="" class="tec14">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec15.png" alt="" class="tec15">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec16.png" alt="" class="tec16">
                    </div>
                    <div class="tech-slide">
                        <img src="images/tec17.png" alt="" class="tec17">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- technologies sec end -->

<!-- Andoird App Development Process start-->
<section class="andoird-app-dev-process">
    <img src="images/ande.png" alt="" class="ande">
    <div class="container">
        <div class="heading">
            <h5>Explore</h5>
            <h2>Our Andoird App Development Process</h2>
            <p>
                Our proficient workflow stands as the cornerstone of our achievements as a leading custom Android app
                development company. With flawless oversight at every stage, we harness premier resources to engineer
                resilient Android applications. Our adept team of developers upholds industry-standard principles
                throughout the development cycle, ensuring excellence in execution.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <d iv class="flawless-digital-slider">
                    <div class="flawless-digital-slide">
                        <h6>UX/UI Design</h6>
                        <p>
                            Our user-centric design process crafts intuitive, frictionless mobile experiences tailored
                            to
                            resonate with your brand and audience through iterative prototyping, usability testing, and
                            ensuring pixel-perfect ease of use. We focus on crafting stunning visuals and interactions
                            that create joy and keep users engaged.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Business Strategy &
                            Product Definition</h6>
                        <p>
                            We start every app project by deeply understanding your business objectives, target users,
                            and long-term goals to define an on-strategy product plan that sets your app up for success.
                            Our research and planning identify how to solve your needs through app functionality that
                            drives real results.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Web Application
                            Development
                        </h6>
                        <p>
                            Our web app developers create progressive web apps leveraging modern frameworks optimized
                            for speed, responsiveness, and dynamic functionality that deliver utility across devices. We
                            build cross-platform web apps that load instantly and feel like native mobile experiences.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>UX/UI Design</h6>
                        <p>
                            Our user-centric design process crafts intuitive, frictionless mobile experiences tailored
                            to
                            resonate with your brand and audience through iterative prototyping, usability testing, and
                            ensuring pixel-perfect ease of use. We focus on crafting stunning visuals and interactions
                            that create joy and keep users engaged.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>UX/UI Design</h6>
                        <p>
                            Our user-centric design process crafts intuitive, frictionless mobile experiences tailored
                            to
                            resonate with your brand and audience through iterative prototyping, usability testing, and
                            ensuring pixel-perfect ease of use. We focus on crafting stunning visuals and interactions
                            that create joy and keep users engaged.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- Andoird App Development Process end-->

<!-- diversified sec start -->
<section class="diversified">
    <div class="container">
        <div class="text-center">
            <h2 class="py-3">Diversified Industry Experience</h2>
            <p>We’ve refined our custom app development expertise across diverse industries, including healthcare,
                finance, retail, media, hospitality, and more. Each has unique needs, which we address through tailored
                solutions focused on user experience and robust functionality. Review client examples from your specific
                vertical to learn how our custom mobile apps solve problems and create value. Let our experience work
                for you!
            </p>
        </div>
        <div class="row pt-5">
            <div class="col-12 col-lg-5 col-md-6 position-relative">
                <div class="Maps whiteInd">
                    <a href="#;">Maps & Navigation</a>
                </div>
                <div class="healthcare pinkInd">
                    <a href="#;">Healthcare</a>
                </div>
                <div class="event whiteInd">
                    <a href="#;">Event & Bookings</a>
                </div>
                <div class="logistics blackInd">
                    <a href="#;">Logistics</a>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 position-relative">
                <div class="social pinkInd">
                    <a href="#;">Social Networking</a>
                </div>
                <div class="entertainment blackInd">
                    <a href="#;">Entertainment</a>
                </div>
                <div class="education pinkInd">
                    <a href="#;">Education & Academics</a>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 position-relative">
                <div class="Food whiteInd">
                    <a href="#;">Food & Restaurant</a>
                </div>
                <div class="business whiteInd">
                    <a href="#;">Business & Finance</a>
                </div>
                <div class="travel blackInd">
                    <a href="#;">Travel & Hotel</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- diversified sec end -->


<!-- game Game-Changing start-->
<section class="game-changing">
    <div class="container">
        <div class="row">
            <div class="col-12 col-xl-10">
                <div class="py-5 game-changing-head">
                    <h5>Explore Our Portfolio</h5>
                    <h2>Explore Our Game-Changing Android App Development Services</h2>
                    <p>We specialize in developing cutting-edge Android applications tailored to enhance your business's
                        digital presence. Our dedicated Android app developers ensure a seamless user experience and
                        integrate innovative features to meet your specific requirements.
                    </p>
                    <p class="mt-3">
                        Discover our range of bespoke Android app development solutions designed to drive your business
                        forward.
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-4 col-md-6 mb-5 p-0">
                <div class="game-changing-col">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>Android App
                        Development Consultation</h6>
                    <p>
                        We bridge the gap between your ideas and Android user expectations. Our consultants tailor
                        strategies to align your business with Android users' needs, helping you make informed choices
                        to stand out in the app store.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 p-0">
                <div class="game-changing-col game-changing-col-acti">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>Android UI/UX Design</h6>
                    <p>
                        Our design team creates exclusive experiences within the Android ecosystem. Trust us to craft
                        seamless user experiences that resonate across all Android devices, ensuring your app stands out
                        and effectively engages users.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-md-6 mb-5 p-0">
                <div class="game-changing-col">
                    <a href="#;">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                    <h6>
                        Android Application
                        Development
                    </h6>
                    <p>
                        Leverage our expertise to build robust and scalable solutions using the latest stack. Our custom
                        Android app services cater to various industries, ensuring your app represents your unique
                        identity amidst competition in the app store.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- seamless mobile exp end-->

<!-- Andoird App Development Process start-->
<section class="andoird-app-dev-process">
    <img src="images/ande.png" alt="" class="ande">
    <div class="container">
        <div class="heading">
            <h5>Explore</h5>
            <h2>Why Opt For Custom Android App Development For Your Business?</h2>
            <p>
                With a dominant market share of 70.5 percent in the third quarter of 2023, Android solidified its
                position as the world's leading mobile operating system. This underscores the strategic importance of
                having an Android app for your business.
                An Android app not only expands your customer base but also elevates customer engagement, making it a
                vital asset for your business growth.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <d iv class="flawless-digital-slider">
                    <div class="flawless-digital-slide">
                        <h6>Unlock a Global Audience</h6>
                        <p>
                            Our user-centric design process crafts intuitive, frictionless mobile experiences tailored
                            to
                            resonate with your brand and audience through iterative prototyping, usability testing, and
                            ensuring pixel-perfect ease of use. We focus on crafting stunning visuals and interactions
                            that create joy and keep users engaged.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Engage Directly
                            with Customers</h6>
                        <p>
                            We start every app project by deeply understanding your business objectives, target users,
                            and long-term goals to define an on-strategy product plan that sets your app up for success.
                            Our research and planning identify how to solve your needs through app functionality that
                            drives real results.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>
                            Boost Visibility
                        </h6>
                        <p>
                            Our web app developers create progressive web apps leveraging modern frameworks optimized
                            for speed, responsiveness, and dynamic functionality that deliver utility across devices. We
                            build cross-platform web apps that load instantly and feel like native mobile experiences.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Fostering
                            Customer Loyalty</h6>
                        <p>
                            Our user-centric design process crafts intuitive, frictionless mobile experiences tailored
                            to
                            resonate with your brand and audience through iterative prototyping, usability testing, and
                            ensuring pixel-perfect ease of use. We focus on crafting stunning visuals and interactions
                            that create joy and keep users engaged.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="flawless-digital-slide">
                        <h6>Precision Targeting</h6>
                        <p>
                            Our user-centric design process crafts intuitive, frictionless mobile experiences tailored
                            to
                            resonate with your brand and audience through iterative prototyping, usability testing, and
                            ensuring pixel-perfect ease of use. We focus on crafting stunning visuals and interactions
                            that create joy and keep users engaged.
                        </p>
                        <a href="" class="btn1">get started <i class="fas fa-chevron-right"></i></a>
                    </div>
            </div>
        </div>
    </div>
</section>
<!-- Andoird App Development Process end-->

<!-- our mission sec start -->
<section class="our-mission">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <img src="images/mission1.png" alt="">
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div class="txt1">
                    <h2>
                        Our Mission - Empowering Your Journey With Innovation & Integrity
                    </h2>
                    <p>
                        At our core, our mission is to empower businesses with transformative digital solutions that
                        drive growth and innovation. We are dedicated to leveraging our expertise and creativity to
                        craft bespoke digital products that meet the unique needs and challenges of each client.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div class="txt2">
                    <h2>
                        Unlock The Power Of Android App Development With The Praetors
                    </h2>
                    <p>
                        When you partner with The Praetors, a leading and reliable Android app development company in
                        the US, you’re selecting a seasoned team of experts poised to transform your concepts into
                        successful applications.
                    </p>
                    <p>
                        We commence by attentively listening to your requirements, ensuring a thorough comprehension of
                        your aspirations.
                        Subsequently, our adept Android app developers utilize their technical prowess to craft
                        applications that not only function seamlessly but also delight end users.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <img src="images/mission2.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- our mission sec end -->


<!-- perks-of-working start -->
<section class="perks-of-working">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div class="text-center">
                    <h5>Explore</h5>
                    <h2 class="py-2">
                        Perks Of Working With An Expert Android App Development Agency
                    </h2>
                    <p>
                        Partnering with The Praetors ensures a seamless journey towards digital transformation through
                        Android app development agency. We carefully handle every aspect to deliver a superior
                        experience, allowing you to effortlessly focus on your business growth.
                    </p>
                </div>
            </div>
        </div>
        <div class="row pt-5">
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks1.jpg" alt="">
                    <div>
                        <h6>
                            Future-Ready Products
                        </h6>
                        <p>
                            We're all about staying ahead of the game, crafting innovative solutions that'll tackle
                            tomorrow’s challenges head-on.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks2.png" alt="">
                    <div>
                        <h6>
                            Dedicated Team
                        </h6>
                        <p>
                            Count on us to bring your ideas to life! Our Android app developers are dedicated, skilled,
                            and ready to make your vision a reality.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks3.jpg" alt="">
                    <div>
                        <h6>
                            Customer Experience
                        </h6>
                        <p>
                            We’re here to make your experience seamless and personalized, tailored just for you and your
                            success.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 mb-5">
                <div class="perks-box">
                    <img src="images/perks4.jpg" alt="">
                    <div>
                        <h6>
                            Satisfaction Guarantee
                        </h6>
                        <p>
                            Your satisfaction is our top priority. We're committed to making sure you're thrilled with
                            the results.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- perks-of-working end -->


<!-- faqs sec start -->
<section class="faqs-sec">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div>
                    <div class="text-center py-5">
                        <h2>Android App Development FAQs</h2>
                    </div>
                    <div class="faq-accordian-sec">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. How long does it take to develop an Android app?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            The time required to develop an Android app varies based on its complexity,
                                            features, and customization needs. Typically, it can take anywhere from a
                                            few weeks to several months.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. What factors influence the cost of Android app development?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Several factors impact the cost, including the app’s complexity, features,
                                            design, development hours, testing, maintenance, and post-launch support
                                            requirements.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. Do I need to have technical knowledge to develop an Android app?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            While technical knowledge can be helpful, it’s not mandatory. Working with a
                                            professional Android app development company allows you to bring your ideas
                                            to life without the need for extensive technical expertise.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFour" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        4. How do you ensure the security of Android apps?
                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            We prioritize security throughout the development process, implementing best
                                            practices for data encryption, secure authentication, and robust
                                            authorization mechanisms to safeguard user data and prevent unauthorized
                                            access.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFive" aria-expanded="false"
                                        aria-controls="collapseFive">
                                        5. Can you assist with publishing the app on the Google Play Store?
                                    </button>
                                </h2>
                                <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Yes, we provide comprehensive support, including assistance with app store
                                            submission, compliance with Google Play Store guidelines, and optimization
                                            of app listings for maximum visibility and reach.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                        6. Do you offer ongoing maintenance and support for Android apps?
                                    </button>
                                </h2>
                                <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Absolutely. We offer maintenance and support services post-launch to ensure
                                            your app remains up-to-date, secure, and optimized for performance. Our team
                                            is available to address any issues, implement updates, and provide technical
                                            assistance as needed.
                                        </p>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            <div class="message-box">
                <ul>
                    <li>
                        <img src="images/message.png" alt="">
                        <h5>Do you have any other <br> question?</h5>
                    </li>
                    <li>
                        <a href="" class="btn1">
                            Get Started <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- faqs sec end -->



<!-- client-say start -->
<section class="client-say">
    <div class="container">
        <div class="heading">
            <h5>Testimonials</h5>
            <h2>What Our client say’s</h2>
            <p>
                Hear first-hand from satisfied clients how our AI/ML development services have delivered tangible
                results. Glowing reviews highlight transformed operations through streamlined processes, increased
                revenues from predictive insights, and deepened relationships underpinned by personalized engagements.
            </p>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="client-say-slider">
                    <div class="client-say-slide">
                        <img src="images/client1.png" alt="" class="pers">
                        <img src="images/client6.png" alt="">
                        <p>
                            The Praetors' customized demand forecasting model far exceeded our expectations. Inventory
                            is perfectly aligned with sales patterns, slashing carrying costs by 20%. I'm impressed by
                            their expertise and professionalism.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Natalia Owens</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client2.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            Since implementing their recommendation engine, our website visits are up 30% as visitors
                            consistently find highly relevant products. Their intuitive dashboard provides insights to
                            constantly refine our strategies. It's clear they truly understand our business.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Thomas Sylvester</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client3.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            As a manufacturing firm striving for efficiency, The Praetors' quality control AI eliminated
                            defect rates and sped up our production line. With their optimized predictive maintenance
                            system, downtime has been reduced to almost zero. Their solutions clearly produce measurable
                            results for us on the factory floor.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Jacob Vasquez</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="client-say-slide">
                        <img src="images/client4.png" alt="" class="pers">
                        <img src="images/client7.png" alt="">
                        <p>
                            The team at The Core Designs listened to everything we wanted in a new website before
                            building it! Our new website is dynamic, fascinating, and straightforward to use for
                            both myself and our viewers. This was by far the smoothest and least painful website
                            change I've ever experienced. I was heard and valued every step of the way. Our new
                            website has surpassed all of our expectations.
                        </p>
                        <h6>The team at The Core Designs...</h6>
                        <ul>
                            <li>
                                <h6>Mike</h6>
                                <span>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                            <li>
                                <img src="images/client5.png" alt="">
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- client-say end -->



<!-- work together start -->
<section class="work-toether">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-6 col-md-6">
                <div>
                    <h5>LET'S WORK TOGETHER</h5>
                    <h2>
                        We're Here <br>
                        To Make It Happen
                    </h2>
                    <p>
                        Join forces with us to bring your digital product visions to life. Let's ignite the spark of
                        innovation and create something truly extraordinary.
                    </p>
                    <img src="images/work1.png" alt="">
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6">
                <form action="">
                    <div class="row">
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Your Name" class="form-label">Your Name</label>
                                <input type="text" id="Your Name" class="form-control" placeholder="Enter your name">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Your Email" class="form-label">Your Email</label>
                                <input type="text" id="Your Email" placeholder="Enter your email" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Company" class="form-label">Company</label>
                                <input type="text" id="Company" placeholder="Company name" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div>
                                <label for="Business Name" class="form-label">Message</label>
                                <textarea name="" id="" placeholder="Write your message"
                                    class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="btn1">
                                Send Message
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- work together end -->



<?php
include 'includes/footer.php';
$page = 'home';
?>